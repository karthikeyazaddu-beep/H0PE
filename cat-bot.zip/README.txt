=== Cat-bot#3315 — Wispbyte Deployment ===

ENVIRONMENT VARIABLES (set in Wispbyte dashboard):
  DISCORD_BOT_TOKEN   Your bot token from discord.com/developers
  SESSION_SECRET      Any random string (e.g. "mysecretkey123")
  PORT                Usually set automatically by Wispbyte

START COMMAND:
  node --enable-source-maps ./dist/index.mjs

MAIN FILE:
  dist/index.mjs

NODE VERSION: 18+
